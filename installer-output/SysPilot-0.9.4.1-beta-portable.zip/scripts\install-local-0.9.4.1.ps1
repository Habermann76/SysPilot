[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$source = 'C:\Users\haber\SysPilot'
$target = 'C:\Program Files\SysPilot'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $source "backup\installed-before-0.9.4.1-$stamp"
New-Item -ItemType Directory -Path $backup -Force | Out-Null
Copy-Item -Path "$target\*" -Destination $backup -Recurse -Force
if (Test-Path "$target\config.json") { Copy-Item "$target\config.json" "$target\config.user-backup.json" -Force }
$files = @('SysPilot.ps1','SysPilot-GUI.ps1','setup-automation.ps1','stop-syspilot.ps1','config.json','version.txt','README.md','INSTALL.md','DEBUG.md','ROADMAP.md','LICENSE','AGENTS.md')
foreach ($item in $files) {
    $src = Join-Path $source $item
    $dst = Join-Path $target $item
    if (Test-Path $src) { Copy-Item -Path $src -Destination $dst -Force }
}
foreach ($folder in @('modules','scripts')) {
    $srcDir = Join-Path $source $folder
    $dstDir = Join-Path $target $folder
    New-Item -ItemType Directory -Path $dstDir -Force | Out-Null
    if (Test-Path $srcDir) { Copy-Item -Path (Join-Path $srcDir '*') -Destination $dstDir -Recurse -Force }
}
# Falls ein früherer Lauf die Ordner falsch verschachtelt hatte, nur diese erzeugten Duplikate entfernen.
foreach ($folder in @('modules','scripts')) {
    $nested = Join-Path (Join-Path $target $folder) $folder
    if (Test-Path $nested) { Remove-Item -Path $nested -Recurse -Force }
}
$setup = Join-Path $target 'setup-automation.ps1'
if (Test-Path $setup) { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $setup -RestoreUserSettings }
Write-Host "Installation aktualisiert: $target" -ForegroundColor Green
Write-Host "Backup: $backup" -ForegroundColor Yellow
Write-Host "Installierte Version: $((Get-Content (Join-Path $target 'version.txt') -Raw).Trim())" -ForegroundColor Green
