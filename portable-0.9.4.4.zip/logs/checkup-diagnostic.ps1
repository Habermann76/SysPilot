﻿$ErrorActionPreference='Stop'
Get-ChildItem 'C:\Users\haber\SysPilot\modules' -Filter '*.psm1' | ForEach-Object { Import-Module $_.FullName -Force -Global -WarningAction SilentlyContinue }
Write-Host 'RUNSPACE CHECKUP START'
$r = Invoke-SysPilotCheckupScan -Quiet
Write-Host "RUNSPACE CHECKUP END: $($r.Count)"
