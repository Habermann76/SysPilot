Import-Module 'C:\Users\haber\SysPilot\modules\Common.psm1' -Force
Import-Module 'C:\Users\haber\SysPilot\modules\Checkup.psm1' -Force
$s = Get-SysPilotCheckupSchedule
Write-Host ("Zeitplan: Enabled=" + $s.Enabled + " Freq=" + $s.Frequency + " Tag=" + $s.Weekday + " Zeit=" + $s.Time + " AutoFix=" + $s.AutoFix)
