Import-Module 'C:\Users\haber\SysPilot\modules\Common.psm1' -Force
Import-Module 'C:\Users\haber\SysPilot\modules\Checkup.psm1' -Force
$items = Get-SysPilotCheckupItems
Write-Host ("Anzahl: " + $items.Count)
$items | ForEach-Object { Write-Host ($_.Id + " | " + $_.Name + " | " + $_.Kategorie) }
