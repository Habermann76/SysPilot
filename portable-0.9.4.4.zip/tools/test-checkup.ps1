$ErrorActionPreference = 'Stop'
$root = 'C:\Users\haber\SysPilot'
Get-ChildItem (Join-Path $root 'modules') -Filter *.psm1 | ForEach-Object { Import-Module $_.FullName -Force -Global -WarningAction SilentlyContinue }

$items = Get-SysPilotCheckupItems
Write-Host ("Checkup-Bereiche: " + $items.Count)
$net = $items | Where-Object { $_.Id -eq 'netrepair' }
Write-Host ("netrepair: " + $net.Name + " | MenuAction=" + $net.MenuAction + " | AutoFix=" + $net.AutoFix)
$scan = & $net.Scan
Write-Host ("Scan: " + $scan.Summary)
$scan.Details | ForEach-Object { Write-Host ("  - " + $_) }
Write-Host ("ActivePlanName: " + (Get-SysPilotActivePlanName))
Write-Host ("ActiveMode: " + (Get-SysPilotActiveMode))
