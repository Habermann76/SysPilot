$root = 'C:\Users\haber\SysPilot'
Get-ChildItem (Join-Path $root 'modules') -Filter *.psm1 | ForEach-Object { Import-Module $_.FullName -Force -Global -WarningAction SilentlyContinue }
$g = Get-SysPilotGuardianConfig
Write-Host ("Guardian: Enabled=" + $g.Enabled + " StartMode=" + $g.StartMode)
Write-Host ("GUI laeuft: " + (Test-SysPilotGuiRunning))
$t = Get-SysPilotToolbox
Write-Host ("Toolbox-Eintraege: " + $t.Count)
$t | Where-Object { $_.Key -in 'checkupschedule','guardian' } | ForEach-Object { Write-Host ("  " + $_.Key + " | " + $_.Name) }
