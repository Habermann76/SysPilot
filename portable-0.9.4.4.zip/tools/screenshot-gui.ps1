# Captures the running SysPilot WPF GUI window to a PNG.
# Finds the real WPF window (HwndWrapper class) via EnumWindows, not MainWindowHandle.
param(
    [string]$OutFile = 'C:\Users\haber\SysPilot\assets\screenshot-gui-new.png',
    [string]$Title = 'SysPilot'
)
Add-Type -AssemblyName System.Drawing
# DPI-aware, damit GetWindowRect physikalische Pixel liefert (CopyFromScreen arbeitet physikalisch)
Add-Type '[System.Runtime.InteropServices.DllImport("user32.dll")] public static extern bool SetProcessDPIAware();' -Name DpiCap -Namespace SysPilotCap
[SysPilotCap.DpiCap]::SetProcessDPIAware() | Out-Null
Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class Win32Cap {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hWnd, StringBuilder sb, int max);
    [DllImport("user32.dll")] public static extern int GetClassName(IntPtr hWnd, StringBuilder sb, int max);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
    [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

    public static void ForceForeground(IntPtr h) {
        // Alt-Tastendruck simulieren: erlaubt SetForegroundWindow aus fremdem Prozess
        keybd_event(0x12, 0, 0, 0); keybd_event(0x12, 0, 2, 0);
        ShowWindow(h, 9); // SW_RESTORE
        BringWindowToTop(h);
        SetForegroundWindow(h);
    }

    public static IntPtr FindWpfWindow(string title) {
        IntPtr found = IntPtr.Zero;
        EnumWindows((h, l) => {
            if (!IsWindowVisible(h)) return true;
            var t = new StringBuilder(256); GetWindowText(h, t, 256);
            if (t.ToString() != title) return true;
            var c = new StringBuilder(256); GetClassName(h, c, 256);
            if (c.ToString().StartsWith("HwndWrapper")) { found = h; return false; }
            return true;
        }, IntPtr.Zero);
        return found;
    }
}
'@

$h = [Win32Cap]::FindWpfWindow($Title)
if ($h -eq [IntPtr]::Zero) { Write-Error "WPF window '$Title' not found"; exit 1 }

[Win32Cap]::ForceForeground($h)
Start-Sleep -Milliseconds 900

$r = New-Object Win32Cap+RECT
[Win32Cap]::GetWindowRect($h, [ref]$r) | Out-Null
$w = $r.Right - $r.Left
$ht = $r.Bottom - $r.Top
if ($w -le 0 -or $ht -le 0) { Write-Error "Invalid window rect ${w}x${ht}"; exit 1 }

$bmp = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($r.Left, $r.Top, 0, 0, $bmp.Size)
$bmp.Save($OutFile, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $bmp.Dispose()
Write-Host "saved $OutFile (${w}x${ht})"
