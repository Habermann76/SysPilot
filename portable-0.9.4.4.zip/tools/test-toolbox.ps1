$root = 'C:\Users\haber\SysPilot'
Get-ChildItem (Join-Path $root 'modules') -Filter *.psm1 | ForEach-Object { Import-Module $_.FullName -Force -Global -WarningAction SilentlyContinue }
$t = Get-SysPilotToolbox
Write-Host ("Toolbox-Eintraege: " + $t.Count)
$t | Where-Object { $_.Key -in 'autooptimize','autopilottask','smartboost' } | ForEach-Object {
    Write-Host ("  " + $_.Key + " | " + $_.Name + " | Admin=" + $_.NeedsAdmin)
}
# SmartBoost-Toggle testen (2x, damit der Wert am Ende stimmt)
$before = [bool](Get-SysPilotConfig).Autopilot.AutoFreeRam
Set-SysPilotConfigValue -Section 'Autopilot' -Key 'AutoFreeRam' -Value (-not $before)
$mid = [bool](Get-SysPilotConfig).Autopilot.AutoFreeRam
Set-SysPilotConfigValue -Section 'Autopilot' -Key 'AutoFreeRam' -Value $before
$after = [bool](Get-SysPilotConfig).Autopilot.AutoFreeRam
Write-Host ("SmartBoost Toggle: $before -> $mid -> $after (OK wenn Anfang=Ende)")
# Shortcut-RunAs (keine Links im Dev-Ordner -> 0 erwartet, kein Fehler)
$n = Set-SysPilotShortcutRunAs -RunAs $true
Write-Host ("Set-SysPilotShortcutRunAs: $n Links geaendert (0 ok im Dev-Ordner)")
