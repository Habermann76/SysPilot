$root = 'C:\Users\haber\SysPilot'
$gui = Join-Path $root 'SysPilot-GUI.ps1'
Write-Host "Starte GUI versteckt mit -StartHidden ..."
$p = Start-Process powershell.exe -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',$gui,'-StartHidden' -PassThru
Write-Host "Gestartet PID: $($p.Id)"
Start-Sleep -Seconds 15
$alive = -not $p.HasExited
Write-Host "Prozess lebt: $alive"
$procs = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match 'SysPilot-GUI' })
Write-Host "GUI-Prozesse: $($procs.Count)"
foreach ($pr in $procs) { Write-Host "  PID $($pr.ProcessId)" }
